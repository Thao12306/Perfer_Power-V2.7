﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Text.RegularExpressions;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        //全局变量
        //10、16进制选择
        byte TEN_ENABLE = 0;
        byte HEX_ENABLE = 0;

        //次方数、求幂运算
        byte INDEX_ENABLE = 0;
        byte POWER_ENABLE = 0;

        //数据格式转换显示
        long SAVE_DATA_HEX = 0;
        long SAVE_DATA_TEN = 0;

        int SAVE_LOGN_HEX = 0;
        int SAVE_LOGN_TEN = 0;

        int SAVE_DATA_OUT = 0;

        long SAVE_DATA_OUT_ULONG = 0;

        //计算错误标识
        byte cal_error_flag = 0;

        //快捷键操作
        byte cal_quick_key_flag = 0;

        //方法封装
        Action<TextBox, string> Show_TextBox_Message;

        //正则表达式
        match_textbox_list match_data = new match_textbox_list();

        public Form1()
        {
            InitializeComponent();        
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Init_View();
        }

         //初始化
        public void Init_View()
        {
            //默认10进制
            TEN_ENABLE = 1;
            HEX_ENABLE = 0;

            //默认次方
            POWER_ENABLE = 0;
            INDEX_ENABLE = 1;

            //默认将光标定在textox3 20:16 2018/10/24
            //以下的写法错误
            //textBox3.Focus();
            //以下的写法正确
            this.textBox3.Select();

            //设置字体颜色

            //只能显示，不能输入信息
            textBox1.ReadOnly = true;
            textBox2.ReadOnly = true;
            textBox5.ReadOnly = true;
            textBox6.ReadOnly = true;
            textBox7.ReadOnly = true;

            button1.Text = "请输入数据!!!";
            button1.BackColor = Color.Green;
            button1.Enabled = false;

            button4.BackColor = Color.Red;

            //委托方法相关操作********************************************************************************************

            //在子线程中更新界面元素
            Show_TextBox_Message = delegate(TextBox show_textbox, string str_in)
            {
                Show_String(show_textbox, str_in);
            };
        }

        //显示字符串
        public void Show_String(TextBox show_textbox, string str_in)
        {
            //if ("".Equals(show_textbox.Text))
            //{
            show_textbox.Text = str_in;
            //}
            //else
            //{
            //    show_textbox.Text += str_in;
            //}
        }

        //计算次方数
        public double Cal_Data_isNN(long data_in, int data_log)
        {
            double cal_cnt = 0;

            if ((data_log > 0) && (data_log != 1))
            {
                cal_cnt = Math.Log(data_in, data_log);//次方的反运算就是log
            }
            else
            {
                MessageBox.Show("底数输出错误!!!,底数不能为0或是1", "错误提示!");
            }
 
            return cal_cnt;
        }

        //计算幂
        public UInt64 Cal_Data_noisNN(int data_in, int data_log)
        {
            UInt64 temp = 1;

            if ((data_log > 0) && (data_log != 1))
            {
                for (int i = 0; i < data_in; i++)
                {
                    temp *= (UInt64)data_log;
                }
            }
            else
            {
                MessageBox.Show("底数输出错误!!!,底数不能为0或是1", "错误提示!");
            }

            return temp;
        }

        //进阶计算次方数
        public void Cal_Data_TWO(TextBox textbox_datain,TextBox textbox_logN)
        {
            double check_cnt = 0;
            UInt64 temp = 0;

            timer1.Start();

            try//修复未输入数据卡死bug 18:06 2018/10/24
            {
                if ((textbox_datain.Text != string.Empty) && (textbox_logN.Text!= string.Empty))
                {
                    if ((TEN_ENABLE == 1) && (HEX_ENABLE == 0))
                    {
                        //计算 
                        //数据保存
                        SAVE_DATA_TEN = Convert.ToUInt32(textbox_datain.Text);
                        SAVE_LOGN_TEN = Convert.ToInt32(textbox_logN.Text);

                        if ((INDEX_ENABLE == 1) && (POWER_ENABLE == 0))//求次方数
                        {
                            check_cnt = Cal_Data_isNN(Convert.ToUInt32(textbox_datain.Text), Convert.ToInt32(textbox_logN.Text));
                        }
                        else if ((INDEX_ENABLE == 0) && (POWER_ENABLE == 1))//求幂
                        {
                            temp = Cal_Data_noisNN(Convert.ToInt32(textbox_datain.Text), Convert.ToInt32(textbox_logN.Text));
                        }
                        else//其它进制暂未实现
                        {

                        }
                        
                    }
                    else if ((TEN_ENABLE == 0) && (HEX_ENABLE == 1))
                    {
                        //计算
                        //数据保存
                        SAVE_DATA_HEX = Convert.ToUInt32(textbox_datain.Text, 16);
                        SAVE_LOGN_HEX = Convert.ToInt32(textbox_logN.Text, 16);

                        if ((INDEX_ENABLE == 1) && (POWER_ENABLE == 0))//求次方数
                        {
                            check_cnt = Cal_Data_isNN(Convert.ToUInt32(textbox_datain.Text, 16), Convert.ToInt32(textbox_logN.Text, 16));
                        }
                        else if ((INDEX_ENABLE == 0) && (POWER_ENABLE == 1))//求幂
                        {
                            temp = Cal_Data_noisNN(Convert.ToInt32(textbox_datain.Text, 16), Convert.ToInt32(textbox_logN.Text, 16));
                        }
                        else//其它进制暂未实现
                        {

                        }
                    }
                    else//其它进制暂未实现
                    {

                    }

                    button1.Text = "计算完毕";
                    button1.BackColor = Color.Red;

                    if ((INDEX_ENABLE == 1) && (POWER_ENABLE == 0))//求次方数
                    {
                        //判断一个数是不是整数
                        if (check_cnt == ((int)check_cnt))
                        {
                            //数据保存
                            SAVE_DATA_OUT = (int)check_cnt;
                            textBox1.Invoke(Show_TextBox_Message, textBox1, check_cnt.ToString());
                            textBox2.Invoke(Show_TextBox_Message, textBox2, "满足次方数计算! 计算成功!!! 转换结果见右下方-->↓↓");

                        }
                        else
                        {
                            //如何将只读属性的textbox的字体改颜色 23:44 2018/10/24
                            //操作如下
                            //错误操作
                            //textBox2.ForeColor = Color.Red;
                            //正确的操作
                            //需要在属性面板设置一下backcolor 即可 将contorl -> 其它 然后设置颜色即可
                            cal_error_flag = 1;
                            textBox1.Invoke(Show_TextBox_Message, textBox1, "Error");
                            textBox2.Invoke(Show_TextBox_Message, textBox2, "不满足次方数计算! 输出数据无效! 请检查输入数据!");
                        }
                    }
                    else if ((INDEX_ENABLE == 0) && (POWER_ENABLE == 1))//求幂
                    {
                        UInt64 temp_check = 0;

                        temp_check = temp;//数据保存
                        temp = temp + 1;// +1 如果溢出 输出结果为1 解决溢出错误!!! 11:22 2018/10/25
                        if(temp <= 1)
                        {
                            cal_error_flag = 2;
                            textBox1.Invoke(Show_TextBox_Message, textBox1, "Error");
                            textBox2.Invoke(Show_TextBox_Message, textBox2, "最大输出:18446744073709551615! 输出数据无效! 请检查输入数据!");
                        }
                        else
                        {
                            //数据保存
                            SAVE_DATA_OUT_ULONG = (long)temp_check;
                            textBox1.Invoke(Show_TextBox_Message, textBox1, temp_check.ToString());
                            textBox2.Invoke(Show_TextBox_Message, textBox2, "满足求幂计算! 计算成功!!! 转换结果见右下方-->↓↓");                         
                        }
                    }
                    else//其它进制暂未实现
                    {

                    }                    
                }
                else
                { 
                
                }
            }
            catch
            {
                timer1.Stop();
                button1.Text = "开始计算";
                button1.BackColor = Color.Green;

                MessageBox.Show("请检查'输入数据'、'底数'","输入错误提示!!!");
            }
        }

        public void Cal_Data_Load_Show()
        {
            //默认光标位置
            this.textBox3.Select();

            try
            {
                if ((textBox3.Text != string.Empty) && (textBox3.Text != string.Empty))
                {
                    button1.Enabled = true;

                    //计算
                    Cal_Data_TWO(textBox3, textBox4);

                    if (cal_error_flag == 0)
                    {
                        if ((INDEX_ENABLE == 1) && (POWER_ENABLE == 0))//求次方
                        {
                            //相应信息的显示
                            if ((TEN_ENABLE == 1) && (HEX_ENABLE == 0))
                            {
                                HEX_T0_TEN_ONE(SAVE_DATA_TEN, SAVE_LOGN_TEN, SAVE_DATA_OUT, textBox6, textBox7, textBox5);
                            }
                            else if ((TEN_ENABLE == 0) && (HEX_ENABLE == 1))
                            {
                                HEX_T0_TEN_ONE(SAVE_DATA_HEX, SAVE_LOGN_HEX, SAVE_DATA_OUT, textBox6, textBox7, textBox5);
                            }
                            else
                            {

                            }
                        }
                        else if ((INDEX_ENABLE == 0) && (POWER_ENABLE == 1))//求幂
                        {
                            //相应信息的显示
                            if ((TEN_ENABLE == 1) && (HEX_ENABLE == 0))
                            {
                                HEX_T0_TEN_TWO(SAVE_DATA_TEN, SAVE_LOGN_TEN, SAVE_DATA_OUT_ULONG, textBox6, textBox7, textBox5);
                            }
                            else if ((TEN_ENABLE == 0) && (HEX_ENABLE == 1))
                            {
                                HEX_T0_TEN_TWO(SAVE_DATA_HEX, SAVE_LOGN_HEX, SAVE_DATA_OUT_ULONG, textBox6, textBox7, textBox5);
                            }
                            else
                            {

                            }
                        }
                        else
                        {

                        }
                    }
                    else
                    {
                        cal_error_flag = 0;
                        textBox5.Invoke(Show_TextBox_Message, textBox5, "Error!!!");
                    }
                }
                else
                {
                    button1.Text = "按键不可操作";
                    button1.Enabled = false;
                }
            }
            catch
            {
                MessageBox.Show("当前没有数据输入!按键 不可操作 请检查'输入数据'、'底数'", "无信息输入错误提示!!!");
            }          
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Cal_Data_Load_Show();
        }

        //以下为快捷键操作 17:18 2018/10/25
        private void 开始计算ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (cal_quick_key_flag == 1)//解决快捷键数据不存在就计算的bug 17:33 2018/10/25
            {
                cal_quick_key_flag = 0;

                Cal_Data_Load_Show();
            }
            else
            {
                cal_quick_key_flag = 0;
            }
        }

        private void 退出程序ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Environment.Exit(0);
        }

        //退出程序
        private void button4_Click(object sender, EventArgs e)
        {
            System.Environment.Exit(0);
        }

        //十进制选择
        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            HEX_ENABLE = 0;
            TEN_ENABLE = 1;
        }

        //十六进制选择
        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            TEN_ENABLE = 0;
            HEX_ENABLE = 1;
        }

        //次方数
        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            POWER_ENABLE = 0;
            INDEX_ENABLE = 1;
        }

        //幂
        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            INDEX_ENABLE = 0;
            POWER_ENABLE = 1;
        }

        //输入数据只能是
        //数字 字母 退格键
        //时间 19:27 2018/10/24
        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((TEN_ENABLE == 1) && (HEX_ENABLE == 0))
            {
                if ((e.KeyChar >= '0' && e.KeyChar <= '9') || (e.KeyChar == 8))
                {
                    e.Handled = false;
                }
                else
                {
                    e.Handled = true;
                }
            }
            else if ((TEN_ENABLE == 0) && (HEX_ENABLE == 1))
            {
                if ((e.KeyChar >= 'a' && e.KeyChar <= 'z') || (e.KeyChar >= 'A' && e.KeyChar <= 'Z')
               || (e.KeyChar >= '0' && e.KeyChar <= '9') || (e.KeyChar == 8))
                {
                    e.Handled = false;
                }
                else
                {
                    e.Handled = true;
                }
            }
            else//其它进制暂未实现
            { 
            
            }        
        }

        //作用同上
        private void textBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((TEN_ENABLE == 1) && (HEX_ENABLE == 0))
            {
                if ((e.KeyChar >= '0' && e.KeyChar <= '9') || (e.KeyChar == 8))
                {
                    e.Handled = false;
                }
                else
                {
                    e.Handled = true;
                }
            }
            else if ((TEN_ENABLE == 0) && (HEX_ENABLE == 1))
            {
                if ((e.KeyChar >= 'a' && e.KeyChar <= 'z') || (e.KeyChar >= 'A' && e.KeyChar <= 'Z')
               || (e.KeyChar >= '0' && e.KeyChar <= '9') || (e.KeyChar == 8))
                {
                    e.Handled = false;
                }
                else
                {
                    e.Handled = true;
                }
            }
            else//其它进制暂未实现
            {

            }
        }

        //专门处理求幂运算
        public void HEX_T0_TEN_TWO(long data_in, int logn_in, long data_out, TextBox in_show, TextBox log_show, TextBox out_show)
        {
            string temp_str = " ";
            string temp_str1 = " ";
            string temp_str2 = " ";

            temp_str = Convert.ToString(data_in, 16);
            temp_str1 = Convert.ToString(logn_in, 16);
            temp_str2 = Convert.ToString(data_out, 16);

            if ((TEN_ENABLE == 1) && (HEX_ENABLE == 0))
            {
                //显示对应的16进制数据
                in_show.Invoke(Show_TextBox_Message, in_show, data_in.ToString() + " " + "->" + " " + temp_str + "(Hex)");
                log_show.Invoke(Show_TextBox_Message, log_show, logn_in.ToString() + " " + "->" + " " + temp_str1 + "(Hex)");
                out_show.Invoke(Show_TextBox_Message, out_show, data_out.ToString() + " " + "->" + " " + temp_str2 + "(Hex)");
            }
            else if ((TEN_ENABLE == 0) && (HEX_ENABLE == 1))
            {
                in_show.Invoke(Show_TextBox_Message, in_show, temp_str + " " + "->" + " " + data_in.ToString() + "(Dec)");
                log_show.Invoke(Show_TextBox_Message, log_show, temp_str1 + " " + "->" + " " + logn_in.ToString() + "(Dec)");
                out_show.Invoke(Show_TextBox_Message, out_show, temp_str2 + " " + "->" + " " + data_out.ToString() + "(Dec)");
            }
            else
            {

            }
        }

        public void HEX_T0_TEN_ONE(long data_in, int logn_in, int data_out, TextBox in_show, TextBox log_show, TextBox out_show)
        {
            string temp_str = " ";
            string temp_str1 = " ";
            string temp_str2 = " ";

            temp_str = Convert.ToString(data_in, 16);
            temp_str1 = Convert.ToString(logn_in, 16);
            temp_str2 = Convert.ToString(data_out, 16);

            if ((TEN_ENABLE == 1) && (HEX_ENABLE == 0))
            {
                //显示对应的16进制数据
                in_show.Invoke(Show_TextBox_Message, in_show,   data_in.ToString() + " " + "->" + " " + temp_str + "(Hex)");
                log_show.Invoke(Show_TextBox_Message, log_show, logn_in.ToString() + " " + "->" + " " + temp_str1 + "(Hex)");
                out_show.Invoke(Show_TextBox_Message, out_show, data_out.ToString() + " " + "->" + " " + temp_str2 + "(Hex)");
            }
            else if ((TEN_ENABLE == 0) && (HEX_ENABLE == 1))
            {
                in_show.Invoke(Show_TextBox_Message, in_show, temp_str + " " + "->" + " " + data_in.ToString() + "(Dec)");
                log_show.Invoke(Show_TextBox_Message, log_show, temp_str1 + " " + "->" + " " + logn_in.ToString() + "(Dec)");
                out_show.Invoke(Show_TextBox_Message, out_show, temp_str2 + " " + "->" + " " + data_out.ToString() + "(Dec)");
            }
            else
            {
            
            }
        }

        //按键按下事件
        //按下 enter 光标自动跳到下一个节点
        private void textBox3_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                textBox4.Focus(); //可以选择光标移动到目标地方      
            }          
        }

        //作用同上
        private void textBox4_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                textBox3.Focus(); //可以选择光标移动到目标地方  
            }
        }

        //显示结果事件 
        //能够张贴复制
        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.Control && e.KeyCode == Keys.V) || (e.Control && e.KeyCode == Keys.C))
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        //计算 快捷键操作
        private void button1_KeyDown(object sender, KeyEventArgs e)
        {

        }

        //更多操作
        private void button3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Perfect Power V2.7 软件会持续更新!\n 目前实现求次方、求幂运算计算。\n 目前参数如下(以底数2为例):\n 求次方 最大: 底数为 2 的 30次方；\n 求   幂 最大: 底数为 2 的 63次方 。 \n 求次方举例：\n 例如输入数据为8，底数为2 则输出结果为3 \n 求幂举例：\n 例如输入数据为3，底数为2 则输出结果为8 \n 作者:廖玥英 \n 联系方式(QQ):1092003911 \n 完成日期:2018/10/25 \n 如果大家在使用过程中发现什么问题或是缺陷，欢迎联系本人，感谢大家的支持! \n ", "关于Perfect Power软件");
        }

        //关于软件
        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("暂未开放!!!敬请期待!!!", "关于更多操作说明");
        }

        //定时器响应函数
        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Stop();

            button1.Text = "开始计算";
            button1.BackColor = Color.Green;           
        }

        //输入数据提示
        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            int temp = 0;

            string temp_textbox3 = " ";
            string temp_textbox4 = " ";

            temp_textbox3 = textBox3.Text;
            temp_textbox4 = textBox4.Text;

            //修复textbox没有输入数据时误判 18:49 2018/10/24
            //注意 这样书写时错误的
            //if ((textBox3.Text != " ") && (textBox4.Text == " "))
            //{
            //}
            //以下为正确的写法

            if ((temp_textbox3 != string.Empty) && (temp_textbox4 == string.Empty))
            {
                button1.Enabled = false;
                cal_quick_key_flag = 2;
                button1.Text = "请输入 '底数' ";
                button1.BackColor = Color.Goldenrod;
            }
            else if ((temp_textbox3 != string.Empty) && (temp_textbox4 != string.Empty))
            {
                temp = Convert.ToInt32(temp_textbox4);
                if ((temp > 0) && (temp != 1))
                {
                    button1.Enabled = true;
                    cal_quick_key_flag = 1;
                    button1.Text = "可以计算";
                    button1.BackColor = Color.GreenYellow;
                }
                else
                {
                    button1.Enabled = false;
                    cal_quick_key_flag = 2;
                    button1.Text = "底数输入不合法，底数 >=2，请输入 '底数' ";
                    button1.BackColor = Color.Goldenrod;
                }
            }
            else if ((temp_textbox3 == string.Empty) && (temp_textbox4 == string.Empty))
            {
                button1.Enabled = false;
                cal_quick_key_flag = 2;
                button1.Text = "不能计算";
                button1.BackColor = Color.GreenYellow;
            }
            else if ((temp_textbox3 == string.Empty) && (temp_textbox4 != string.Empty))
            {
                button1.Enabled = false;
                cal_quick_key_flag = 2;
                button1.Text = "请输入 '输入数据' ";
                button1.BackColor = Color.Goldenrod;
            }
            else
            { }
        }

        //输底数提示
        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            int temp = 0;

            string temp_textbox3 = " ";
            string temp_textbox4 = " ";

            temp_textbox3 = textBox3.Text;
            temp_textbox4 = textBox4.Text;

            if ((temp_textbox4 != string.Empty) && (temp_textbox3 == string.Empty))
            {
                button1.Enabled = false;
                cal_quick_key_flag = 2;
                button1.Text = "请输入 '输入数据' ";
                button1.BackColor = Color.Goldenrod;
            }
            else if ((temp_textbox4 != string.Empty) && (temp_textbox3 != string.Empty))
            {
                temp = Convert.ToInt32(temp_textbox4);
                if ((temp > 0) && (temp != 1))
                {
                    button1.Enabled = true;
                    cal_quick_key_flag = 1;
                    button1.Text = "可以计算";
                    button1.BackColor = Color.GreenYellow;
                }
                else
                {
                    button1.Enabled = false;
                    cal_quick_key_flag = 2;
                    button1.Text = "底数输入不合法，底数 >=2，请输入 '底数' ";
                    button1.BackColor = Color.Goldenrod;
                }
            }
            else if ((temp_textbox4 == string.Empty) && (temp_textbox3 == string.Empty))
            {
                button1.Enabled = false;
                cal_quick_key_flag = 2;
                button1.Text = "不能计算";
                button1.BackColor = Color.GreenYellow;
            }
            else if ((temp_textbox4 == string.Empty) && (temp_textbox3 != string.Empty))
            {
                button1.Enabled = false;
                cal_quick_key_flag = 2;
                button1.Text = "请输入 '底数' ";
                button1.BackColor = Color.Goldenrod;
            }
            else
            { }
        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
        }

        /*########################################################################普通程序执行区域 开始###################################*/

        //在这里暂时用不上
        //textbox控件输入 正则表达式 自动去空等非法检测################################################################################开始
        //需要引入
        //using System.Text.RegularExpressions;

        public class match_textbox_list
        {
            //构造函数
            public match_textbox_list()
            {

            }

            //限制输入额数据为 数字或是字母
            //string PATTERN = @"([^A-Fa-f0-9]|\s+?)+";
            string pattern = @"^[0-9]*$";

            public string Match_TextBox_num09_ONE(string str_in)
            {
                string str = " ";
                string str_out = " ";

                str = str_in.Trim();//自动去空

                if (str.Contains(" "))
                {
                    str = str.Replace(" ", "");
                }

                Match m = Regex.Match(str, pattern);//匹配正则表达式 

                if (!m.Success)//输入的不是数字
                {
                    MessageBox.Show("输入数据非法！0-9之间的数据允许输入", "数据输入非法提示");
                }
                else //输入的是数字
                {
                    str_out = str;
                }

                return str_out;
            }

            public string[] Match_TextBox_num09_TWO(string[] str_in, int cnt)
            {
                string[] str = new string[128];
                string[] str_out = new string[128];

                for (int i = 0; i < cnt; i++)
                {
                    str[i] = str_in[i].Trim();      //自动去空

                    if (str[i].Contains(" "))
                    {
                        str[i] = str[i].Replace(" ", "");
                    }

                    Match m = Regex.Match(str[i], pattern);//匹配正则表达式 

                    if (!m.Success)//输入的不是数字
                    {
                        MessageBox.Show("要修改数据非法！请输入0-9之间的数据", "数据输入非法提示");
                    }
                    else //输入的是数字
                    {
                        str_out[i] = str[i];
                    }
                }
                return str_out;
            }
        }

        //textbox控件输入 正则表达式 自动去空等非法检测################################################################################结束

        /*########################################################################普通程序执行区域 结束###################################*/

    }
}
